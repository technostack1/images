// server.js

const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const Project = require('./models/project');

const app = express();
const PORT = 3001;

app.use(express.json());
app.use(cors({
    origin: 'http://localhost:3000'
}));

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/bidding', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Connected to MongoDB');
}).catch((error) => {
  console.error('Error connecting to MongoDB:', error);
});

// Endpoint to handle submission of new projects
app.post('/api/projects', async (req, res) => {
  const { title, description, budget } = req.body;

  try {
    // Create a new project document
    const newProject = await Project.create({ title, description, budget });
    res.status(200).json({ message: 'New project submitted successfully', project: newProject });
  } catch (error) {
    console.error('Error creating project:', error);
    res.status(500).json({ message: 'Error submitting new project' });
  }
});


// Endpoint to get all projects
app.get('/api/projects', async (req, res) => {
    try {
      // Retrieve all projects from the database
      const projects = await Project.find();
      res.status(200).json(projects);
    } catch (error) {
      console.error('Error retrieving projects:', error);
      res.status(500).json({ message: 'Error retrieving projects' });
    }
  });
// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
