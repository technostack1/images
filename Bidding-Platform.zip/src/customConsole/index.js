let customConsole= msg =>{
    if(msg){
        console.log(msg)
    }
}

export default customConsole